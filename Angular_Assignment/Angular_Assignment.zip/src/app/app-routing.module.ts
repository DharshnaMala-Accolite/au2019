import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeesComponent } from './employees/employees.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { DepartmentComponent } from './department/department.component';
import { DepartmentDetailsComponent } from './department-details/department-details.component';
import { ListComponent } from './todo/list/list.component';
import { TodoComponent } from './todo/todo.component';
import { DetailsComponent } from './todo/details/details.component';
const routes: Routes = [
  { path: 'employees', component: EmployeesComponent },
  { path: 'departments', component: DepartmentComponent },
  { path: 'employeedetails/:id', component: EmployeeDetailsComponent },
  { path: 'departmentdetails/:name', component: DepartmentDetailsComponent },
  { path: 'todo', component: TodoComponent},
  { path: 'todo/list', component: ListComponent},
  { path: 'details/:taskid', component: DetailsComponent}
  // { path: '', redirectTo: '/employees', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
