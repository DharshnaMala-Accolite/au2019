import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Department } from '../department';

@Component({
  selector: 'app-department-details',
  templateUrl: './department-details.component.html',
  styleUrls: ['./department-details.component.scss']
})
export class DepartmentDetailsComponent implements OnInit {
  deptDetail: Department [];
  deptName: String;
  deptId: number;
  constructor(private route: ActivatedRoute, public empserv : EmployeeService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      let name = params['name'];
      this.deptName = name;
      console.log(name);
      })
      if(this.deptName=='ECE')
        this.deptId=4;
      else if(this.deptName=='CSE')
        this.deptId=3;
      else if(this.deptName=='Maths')
        this.deptId=6;
      else if(this.deptName=='Aero')
        this.deptId=1;
      console.log(this.deptId);
      this.getDeptDetail();
  }
  public getDeptDetail() {
    this.empserv.getDepartmentDetails().subscribe((data) => {
    this.deptDetail = data;
    console.log("this.deptdetail:");
    console.log(this.deptDetail);
  });
}
}
