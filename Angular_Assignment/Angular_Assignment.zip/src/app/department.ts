export class Department {
    id : Number;
    name : string;
    location : string;
    
    constructor(){
    this.id = 1;
    this.name = ""; 
    this.location="";
    }
}
