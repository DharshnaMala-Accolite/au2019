import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.scss']
})
export class DepartmentComponent implements OnInit {

  employees : any;
  constructor(private route: ActivatedRoute, public empserv : EmployeeService) { }

  ngOnInit() {
    this.getEmp();
  }
  public getEmp() {

    this.empserv.getEmployees().subscribe((data) => {
    this.employees = data;
    const uniqueDept = Array.from(new Set(this.employees.map(a => a.department))).map(department => {
        return this.employees.find(a => a.department === department)
    })
    this.employees = uniqueDept;
  });
}

}
