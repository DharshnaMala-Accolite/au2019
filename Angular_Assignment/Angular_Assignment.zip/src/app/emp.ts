
export class Emp {
    id : Number;
    name : string;
    city : string;
    gender : string;
    department : string;
    
    constructor(){
    this.id = 1;
    this.name = ""; //setting default value
    this.city = "";
    this.gender="";
    this.department="";
    }
}
    
   