import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Emp } from '../emp';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.scss']
})
export class EmployeeDetailsComponent implements OnInit {

  // empDetail: Emp [];
  empDetail: any;
  empId: number;
  isupdate: Boolean = false;
  constructor(private route: ActivatedRoute, public empserv : EmployeeService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
    let id = params['id'];
    this.empId = id;
    console.log(id);
    })
    this.getEmpDetail(this.empId);
  }
  public getEmpDetail(id) {
      this.empserv.getEmployeesDetails(id).subscribe((data) => {
      this.empDetail = data;
      console.log("this.empdetail:");
      console.log(this.empDetail);
    });
  }
  public updateEmp(id){
    this.isupdate=true;
  }
  public cancelUpdate()
  {
    this.isupdate=false;
  }
  public saveEmp(empid,name,city,gender,dept)
  {
    console.log(empid,name,city,gender,dept);
    this.isupdate=false;
    var jobj = {
          "id": empid,
          "name": name,
          "city": city,
          "gender": gender,
          "department": dept
    }
    console.log(jobj);
    // this.empserv.updateEmployee(jobj).subscribe((data) => {
    //   this.empDetail = data;
    //   console.log("this.empdetail:");
    //   console.log(this.empDetail);
    // });
    this.empserv.updateEmployee(empid,name,city,gender,dept);
  }
 
}
