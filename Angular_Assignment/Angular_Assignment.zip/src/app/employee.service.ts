import { Injectable } from '@angular/core';
import {Http, Response, Headers, RequestOptions, RequestMethod} from '@angular/http';
import { Observable } from 'rxjs';
import { Emp } from './emp';
import { map } from 'rxjs/operators';
 import { HttpClient } from '@angular/common/http';
import 'rxjs';
import { Department } from './department';
import { Todo } from './todo';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 

  constructor(private http: Http, private httpclient : HttpClient) {
   
   }
//    public getJSON(): Observable<Emp[]> {
     
//     const jsonobj = this.httpClient.get("./assets/Employee.json");
//     this.usersJson = Array.of(jsonobj);
//     return this.usersJson;
// }
// getEmployees():Observable<Emp[]>{
//  // return this.http.get('assets/Employee.json').pipe(map((response:Response) => <Emp[]> response.json()));
// // return this.http.get('assets/Employee.json').pipe(map((res:Response) => <Emp[]> res.json()));
// //USING THE jsonSERVER
// return this.http.get('http://localhost:3000/employee ').pipe(map((res:Response) => <Emp[]> res.json())); 
// }
getEmployees(){
  // return this.http.get('assets/Employee.json').pipe(map((response:Response) => <Emp[]> response.json()));
 // return this.http.get('assets/Employee.json').pipe(map((res:Response) => <Emp[]> res.json()));
 //USING THE jsonSERVER
 return this.httpclient.get('http://localhost:3000/employee '); 
 }
// getEmployeesDetails(id) {
//   // console.log("Inside get employees function:");
//   // console.log(this.http.get('http://localhost:3000/employee ').pipe(map((res:Response) => <Emp[]> res.json()))); 
//   return this.http.get('http://localhost:3000/employee/1 ').pipe(map((res:Response) => <Emp[]> res.json())); 

// }
getEmployeesDetails(id) {
  let empid=id;
  console.log(empid);
  // console.log("Inside get employees function:");
  // console.log(this.http.get('http://localhost:3000/employee ').pipe(map((res:Response) => <Emp[]> res.json()))); 
  return this.httpclient.get('http://localhost:3000/employee/'+empid); 

}
deleteEmployee(id) {
  let empid=id;
  console.log(empid);
  // console.log("Inside get employees function:");
  // console.log(this.http.get('http://localhost:3000/employee ').pipe(map((res:Response) => <Emp[]> res.json()))); 
  return this.httpclient.delete('http://localhost:3000/employee/'+empid); 

}
updateEmployee(empid,nam,cit,gender,dept){
  // return this.httpclient.put('http://localhost:3000/employee/' , 
  // {
  //          "id": empid,
  //         "name": name,
  //         "city": city,
  //         "gender": gender,
  //         "department": dept
  // }).subscribe(data  => {console.log("PUT Request is successful ", data); }, error  => { console.log("Rrror", error); });

  fetch('http://localhost:3000/employee/'+ empid, {
    method: 'PUT',
    body: JSON.stringify({
      id: empid,
      name: nam,
      city: cit,
      gender: gender,
      department : dept
    }),
    headers: {
      "Content-type": "application/json; charset=UTF-8"
    }
  })
  .then(response => response.json())
  .then(json => console.log(json))

}

getDepartmentDetails():Observable<Department[]> {
  return this.http.get('assets/dept.json').pipe(map((res:Response) => <Department[]> res.json()));
}
// getTodoDetails():Observable<Todo[]> {
//   return this.http.get('assets/todo.json').pipe(map((res:Response) => <Todo[]> res.json()));
// }
getTodoDetails()
{
  return this.httpclient.get('http://localhost:3000/todo '); 
}
updateDetails(id1,task1,weeks1,team1){

  fetch('http://localhost:3000/todo/'+ id1, {
    method: 'PUT',
    body: JSON.stringify({
      id: id1,
      task: task1,
      weeks: weeks1,
      team: team1,
    }),
    headers: {
      "Content-type": "application/json; charset=UTF-8"
    }
  })
  .then(response => response.json())
  .then(json => console.log(json))

}
}
