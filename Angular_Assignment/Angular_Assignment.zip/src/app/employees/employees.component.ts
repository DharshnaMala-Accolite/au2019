import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Emp } from '../emp';
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss']
})
export class EmployeesComponent implements OnInit {

    //employees: Emp [];
    employees: any;
    constructor(private route: ActivatedRoute, public empserv : EmployeeService) { }
 

  ngOnInit() {
    this.getEmp();
  }
  public getEmp() {

      this.empserv.getEmployees().subscribe((data) => {
      this.employees = data;
    });
  }
  public deleteEmp(id)
  {
     this.empserv.deleteEmployee(id).subscribe((data) => {
      this.employees = data;
    });
  }
}
