export class Todo {
    id : Number;
    task : string;
    weeks : Number;
    team : string;
    
    
    constructor(){
    this.id = 1;
    this.task = ""; 
    this.weeks = 1;
    this.team="";
    }
}
