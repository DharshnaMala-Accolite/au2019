import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/todo';
import { EmployeeService } from 'src/app/employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {

  details : any;
  taskid : Number;
  isupdate: Boolean = false;
  constructor(private route: ActivatedRoute, public empserv : EmployeeService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      let name = params['taskid'];
      this.taskid = name;
      console.log(name);
      })
      this.getTaskDetail();
  }
  getTaskDetail(){
      this.empserv.getTodoDetails().subscribe((data) => {
      this.details = data;
    });
  }
  public updateDept(id){
    this.isupdate=true;
  }
  public cancelUpdate()
  {
    this.isupdate=false;
  }
  public saveEmp(id,task,weeks,team)
  {
    console.log(id,task,weeks,team);
    this.isupdate=false;
    var jobj = {
          "id": id,
          "task": task,
          "weeks": weeks,
          "team": team
    }
    console.log(jobj);
    this.empserv.updateDetails(id,task,weeks,team);
  }
}
