import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/todo';
import { EmployeeService } from 'src/app/employee.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  todoDetail : any;
  constructor(private route: ActivatedRoute, public empserv : EmployeeService) { }

  ngOnInit() {
    this.getTodo();
  }
  getTodo(){
    this.empserv.getTodoDetails().subscribe((data) => {
      this.todoDetail = data;
    });
  }
}
