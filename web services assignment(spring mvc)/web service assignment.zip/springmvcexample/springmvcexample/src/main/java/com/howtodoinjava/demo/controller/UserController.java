package com.howtodoinjava.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.howtodoinjava.demo.dao.UserDAOImp;
import com.howtodoinjava.demo.model.LoginUser;
import com.howtodoinjava.demo.model.User;

@Controller
public class UserController {
	
	
	@Autowired
	UserDAOImp userdaoimp;
	
	@RequestMapping("/home")
	public String create(Model m)
	{
		System.out.println("hello");
		String message="";
		m.addAttribute("message",message);
		return "register";
	}
	

	@RequestMapping("/admin")
	public String adminLogin()
	{
		return "admin";
	}
	
	@RequestMapping("/registerpage")
	public String register(HttpServletRequest req,Model m)
	{
		String fname=req.getParameter("firstname");
		String lname=req.getParameter("lastname");
		String email=req.getParameter("email");
		String password=req.getParameter("psw");
		String pass=req.getParameter("psw-repeat");
		String message;
		int errorc=0;
		long waittime = 0;
		message="Welcome" + fname+"!";
		m.addAttribute("message", message);
		User u = new User(fname,lname,email,password,errorc,waittime);
		userdaoimp.saveUser(u);
		return "login";
	}
	
	@RequestMapping("/login")
	public String login(Model m)
	{
		String message = "";
		m.addAttribute("message", message);
		return "login";
	}
	
	@RequestMapping("/logincheck")
	public String logincheck(HttpServletRequest req,Model m)
	{
		String name = req.getParameter("uname");
		System.out.println(name);
		String pass = req.getParameter("psw");
		List<User> userList;
		String message;
		userList = userdaoimp.getValidUsers(name);
		System.out.println(userList.size());
		message="";
		m.addAttribute("message",message);
		if(userList.size()==0)
		{
			message="User does not exit!Register first!";
			m.addAttribute("message",message);
			System.out.println("User does not exit!Register first!");
			return "register";
		}
		else 
		{
			for(User u: userList)
			{
				if(u.getPassword().equals(pass))
				{

					int errorCount = 0;
					long cur= System.currentTimeMillis();
					long wait=cur-u.getWaittime();
					wait=(wait/1000)/60;
					errorCount = u.getErrorC();
					String status;
					switch(errorCount)
					{
						case 3 : 
									if(wait<5)
									{
										long w=5-wait;
										message="Wait for "+w+" minutes!";
										m.addAttribute("message", message);
										System.out.println(message);
										status="Waiting!";
										userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
										return "login";
									}
									else
									{
										status="Logged In!";
										message="Successfully Logged In!";
										m.addAttribute("message",message);
										userdaoimp.changeErrorandTime(u.getFirstName(),u.getPassword(),0,0);
										userdaoimp.deleteIfExists(u.getFirstName());
										userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
										status="Logged In!";
										return "loginresult";
									}
						case 6 :
										if(wait<10)
										{
											status="Waiting!";
											long w=10-wait;
											message="Wait for "+w+" minutes!";
											m.addAttribute("message", message);
											System.out.println(message);
											userdaoimp.deleteIfExists(u.getFirstName());
											userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
											return "login";
										}
										else
										{
											message="Successfully Logged In!";
											m.addAttribute("message",message);
											userdaoimp.changeErrorandTime(u.getFirstName(),u.getPassword(),0,0);
											status="Logged In!";
											userdaoimp.deleteIfExists(u.getFirstName());
											userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
											return "loginresult";
										}
						case 9 : 
									if(wait<20)
									{
										status="Waiting!";
										long w=20-wait;
										message="Wait for "+w+" minutes!";
										m.addAttribute("message", message);
										System.out.println(message);
										userdaoimp.deleteIfExists(u.getFirstName());
										userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
										return "login";
									}
									else
									{
										message="Successfully Logged In!";
										m.addAttribute("message",message);
										userdaoimp.changeErrorandTime(u.getFirstName(),u.getPassword(),0,0);
										status="Logged In!";
										userdaoimp.deleteIfExists(u.getFirstName());
										userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
										return "loginresult";
									}
						case 12 : message="User blocked";
							      m.addAttribute("message",message);
								  status="User Invalid/Blocked!";
								  userdaoimp.deleteIfExists(u.getFirstName());
								  userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
								  userdaoimp.removeUser(u.getFirstName());
						          break;
						default: userdaoimp.changeErrorandTime(u.getFirstName(),u.getPassword(),0,0);
								message="Successfully Logged In!";
								status="Logged In!";
								userdaoimp.deleteIfExists(u.getFirstName());
								userdaoimp.createAdminView(u.getFirstName(),u.getEmail(),status);
								m.addAttribute("message",message);
								break;
					}
				}
				else
				{
					System.out.println(u.getFirstName()+" "+u.getErrorC()+" "+u.getWaittime());
					message="Password Error!Try LOGGING again!";
					long curtime= System.currentTimeMillis();
					m.addAttribute("message",message);
					int curerr = userdaoimp.getError(name);
					curerr += 1;
					userdaoimp.updateError(name,curerr,curtime);
					return "Fail";
				}
			}
			System.out.println("User found");
		}
		return "loginresult";
	}
	
	@RequestMapping("/adminview")
	public String adminView(HttpServletRequest req,Model m)
	{
		System.out.println("I side admin view");
		String name=req.getParameter("username");
		String pass=req.getParameter("password");
		int row=0;
		if(name.equals("dharshna") && pass.equals("dharshna"))
		{		
				System.out.println("Logging in as Admin");
				m.addAttribute("users",userdaoimp.viewUser());
				return "view";
		}
		else
			return "admin";
	}
	
}
