package com.howtodoinjava.demo.dao;
import com.howtodoinjava.demo.model.User;
public interface UserDAO {
	long saveUser(User user);
}
