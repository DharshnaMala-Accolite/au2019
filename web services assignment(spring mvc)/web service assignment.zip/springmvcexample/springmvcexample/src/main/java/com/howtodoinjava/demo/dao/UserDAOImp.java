package com.howtodoinjava.demo.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.howtodoinjava.demo.model.User;
import com.howtodoinjava.demo.model.LoginUser;

@Repository
public class UserDAOImp implements UserDAO{

	@Autowired
	JdbcTemplate jTemplate;
	
	public long saveUser(User user) {
		String sql;
		sql = "INSERT INTO REGISTER(FIRSTNAME,LASTNAME,EMAIL,PASSWORD,ERRORC,WAITTIME)"+" VALUES('"+user.getFirstName()+"','"+user.getLastName()+"','"+user.getEmail()+"','"+user.getPassword()+"','"+user.getErrorC()+"','"+user.getWaittime()+"')";
		System.out.println(sql);
		this.jTemplate.execute(sql);
		return 1;
	}
	
	public List<LoginUser> viewUser() {
		String sql = "select * from login ";
		return this.jTemplate.query(sql, new RowMapper<LoginUser>(){
			public LoginUser mapRow(ResultSet rs, int arg1) throws SQLException {
				LoginUser m = new LoginUser();
				m.setUsername(rs.getString("firstname"));
				m.setPassword(rs.getString("email"));
				m.setStatus(rs.getString("user_status"));
				return m;
			}
		});
	}
	
	public void changeErrorandTime(String name,String pass,int err,long tim)
	{
		String sql;
		sql = "UPDATE REGISTER SET errorc='"+err+"' and waittime='"+tim+"' WHERE firstname='"+name+"' AND password='"+pass+"';";
		System.out.println(sql);
		this.jTemplate.execute(sql);
	}
	
	public List<User> getValidUsers(String name)
	{
		String sql="select * from register where firstname='"+name+"';";
		List<User> users = this.jTemplate.query(sql, new RowMapper<User>(){
			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				User m = new User();
				m.setFirstName(rs.getString("firstname"));
				m.setLastName(rs.getString("lastname"));
				m.setEmail(rs.getString("email"));
				m.setPassword(rs.getString("password"));
				m.setErrorC(rs.getInt("errorc"));
				m.setWaittime(rs.getLong("waittime"));
				return m;
			}
		});
		return users;
	}

	public void updateError(String name, int error, long cur) {
		String sql;
		sql = "UPDATE REGISTER SET errorc='"+error+"' WHERE firstname='"+name+"';";
		System.out.println(sql);
		this.jTemplate.execute(sql);
		sql = "UPDATE REGISTER SET waittime='"+cur+"' WHERE firstname='"+name+"';";
		System.out.println(sql);
		this.jTemplate.execute(sql);
	}

	public int getError(String name) {
		String sql="select * from register where firstname='"+name+"';";
		System.out.println(sql);
		List<User> users = this.jTemplate.query(sql, new RowMapper<User>(){
			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				User m = new User();
				m.setFirstName(rs.getString("firstname"));
				m.setLastName(rs.getString("lastname"));
				m.setEmail(rs.getString("email"));
				m.setPassword(rs.getString("password"));
				m.setErrorC(rs.getInt("errorc"));
				m.setWaittime(rs.getLong("waittime"));
				return m;
			}
		});
		User u = users.get(0);
		return u.getErrorC();
	}

	public void removeUser(String name) {
		String sql;
		sql="DELETE from register where firstname='"+name+"';";
		System.out.println(sql);
		this.jTemplate.execute(sql);
		
	}

	public void createAdminView(String name, String email, String status) {
		String sql;
		sql = "INSERT INTO LOGIN(FIRSTNAME,EMAIL,USER_STATUS)"+" VALUES('"+name+"','"+email+"','"+status+"')";
		System.out.println(sql);
		this.jTemplate.execute(sql);
	}

	public void deleteIfExists(String name) {
		String sql="delete from login where firstname='"+name+"';";
		System.out.println(sql);
		this.jTemplate.execute(sql);
	}
}
