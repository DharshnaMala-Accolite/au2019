package com.howtodoinjava.demo.model;

public class User {

	public User() {
	}
	String firstName;
	String lastName;
	String email;
	String password;
	int errorC;
	long waittime;
	String user_status;
	
	public User(String firstName, String lastName, String email, String password,int errorC,long waittime) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.errorC = errorC;
		this.waittime = waittime;
		this.user_status="";
	}
	public long getWaittime() {
		return waittime;
	}
	public void setWaittime(long waittime) {
		this.waittime = waittime;
	}
	public int getErrorC() {
		return errorC;
	}
	public void setErrorC(int errorC) {
		this.errorC = errorC;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
